package com.example.cylens7

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import android.content.pm.PackageManager

class Galleryview : AppCompatActivity() {

    private lateinit var imageUris: List<Uri>
    private lateinit var recyclerView: RecyclerView
    private lateinit var imageAdapter: ImageAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_galleryview)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(this, 3)

        // Call the method to request storage permissions
        requestStoragePermission()

        val galleryButton = findViewById<ImageButton>(R.id.galleryButton)
        galleryButton.setOnClickListener {
            loadImagesFromGallery()
        }
    }

    private fun requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
                if (isGranted) {
                    loadImagesFromGallery()
                } else {
                    Toast.makeText(this, "Storage permission denied", Toast.LENGTH_SHORT).show()
                }
            }.launch(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            loadImagesFromGallery()
        }
    }

    private fun loadImagesFromGallery() {
        val picturesDir = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "CyLensScreenshots")

        if (!picturesDir.exists()) {
            picturesDir.mkdirs()
        }

        // Check if the directory is accessible
        if (picturesDir.isDirectory) {
            // List files and filter for images
            val imageFiles = picturesDir.listFiles { file -> file.isFile && file.extension in listOf("jpg", "jpeg", "png") }
            if (imageFiles != null && imageFiles.isNotEmpty()) {
                // Load URIs
                imageUris = imageFiles.sortedByDescending { it.lastModified() }
                    .map { file -> FileProvider.getUriForFile(this, "${packageName}.provider", file) }

                // Check if URIs are loaded
                if (imageUris.isNotEmpty()) {
                    imageAdapter = ImageAdapter(this, imageUris) { uri ->
                        openImage(uri)
                    }
                    recyclerView.adapter = imageAdapter
                } else {
                    Toast.makeText(this, "No images found in the directory", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "No screenshots available to display", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Pictures directory not found", Toast.LENGTH_SHORT).show()
        }
    }


    private fun openImage(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "image/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "No app available to view images", Toast.LENGTH_SHORT).show()
        }
    }
}
