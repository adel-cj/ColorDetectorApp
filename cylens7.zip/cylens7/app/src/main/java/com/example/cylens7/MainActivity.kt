package com.example.cylens7

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.util.Size
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.example.cylens7.databinding.ActivityMainBinding
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sqrt
import kotlin.math.pow
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var imageCapture: ImageCapture

    private val colorMap = mapOf(
        // Red shades
        "Red" to Pair("#FF0000", Color.rgb(255, 0, 0)),
        "Dark Red" to Pair("#8B0000", Color.rgb(139, 0, 0)),
        "Light Coral" to Pair("#F08080", Color.rgb(240, 128, 128)),
        "Indian Red" to Pair("#CD5C5C", Color.rgb(205, 92, 92)),
        "Salmon" to Pair("#FA8072", Color.rgb(250, 128, 114)),

        // Orange shades
        "Orange" to Pair("#FF7F00", Color.rgb(255, 127, 0)),
        "Dark Orange" to Pair("#FF8C00", Color.rgb(255, 140, 0)),
        "Coral" to Pair("#FF7F50", Color.rgb(255, 127, 80)),
        "Tomato" to Pair("#FF6347", Color.rgb(255, 99, 71)),
        "Peach" to Pair("#FFE5B4", Color.rgb(255, 229, 180)),

        // Yellow shades
        "Yellow" to Pair("#FFFF00", Color.rgb(255, 255, 0)),
        "Gold" to Pair("#FFD700", Color.rgb(255, 215, 0)),
        "Light Yellow" to Pair("#FFFFE0", Color.rgb(255, 255, 224)),
        "Khaki" to Pair("#F0E68C", Color.rgb(240, 230, 140)),
        "Pale Goldenrod" to Pair("#EEE8AA", Color.rgb(238, 232, 170)),

        // Green shades
        "Chartreuse Green" to Pair("#7FFF00", Color.rgb(127, 255, 0)),
        "Green" to Pair("#00FF00", Color.rgb(0, 255, 0)),
        "Forest Green" to Pair("#228B22", Color.rgb(34, 139, 34)),
        "Lime Green" to Pair("#32CD32", Color.rgb(50, 205, 50)),
        "Pale Green" to Pair("#98FB98", Color.rgb(152, 251, 152)),

        // Cyan shades
        "Cyan" to Pair("#00FFFF", Color.rgb(0, 255, 255)),
        "Light Cyan" to Pair("#E0FFFF", Color.rgb(224, 255, 255)),
        "Dark Cyan" to Pair("#008B8B", Color.rgb(0, 139, 139)),
        "Aqua" to Pair("#00FFFF", Color.rgb(0, 255, 255)),
        "Teal" to Pair("#008080", Color.rgb(0, 128, 128)),

        // Blue shades
        "Blue" to Pair("#0000FF", Color.rgb(0, 0, 255)),
        "Medium Blue" to Pair("#0000CD", Color.rgb(0, 0, 205)),
        "Dark Blue" to Pair("#00008B", Color.rgb(0, 0, 139)),
        "Sky Blue" to Pair("#87CEEB", Color.rgb(135, 206, 235)),
        "Dodger Blue" to Pair("#1E90FF", Color.rgb(30, 144, 255)),

        // Violet shades
        "Violet" to Pair("#7F00FF", Color.rgb(127, 0, 255)),
        "Dark Violet" to Pair("#9400D3", Color.rgb(148, 0, 211)),
        "Orchid" to Pair("#DA70D6", Color.rgb(218, 112, 214)),
        "Lavender" to Pair("#E6E6FA", Color.rgb(230, 230, 250)),
        "Plum" to Pair("#DDA0DD", Color.rgb(221, 160, 221)),

        // Magenta shades
        "Magenta" to Pair("#FF00FF", Color.rgb(255, 0, 255)),
        "Hot Pink" to Pair("#FF69B4", Color.rgb(255, 105, 180)),
        "Deep Pink" to Pair("#FF1493", Color.rgb(255, 20, 147)),
        "Fuchsia" to Pair("#FF00FF", Color.rgb(255, 0, 255)),
        "Pale Violet Red" to Pair("#DB7093", Color.rgb(219, 112, 147)),

        // Rose shades
        "Rose" to Pair("#FF007F", Color.rgb(255, 0, 127)),
        "Light Pink" to Pair("#FFB6C1", Color.rgb(255, 182, 193)),
        "Misty Rose" to Pair("#FFE4E1", Color.rgb(255, 228, 225)),
        "Pale Pink" to Pair("#FADADD", Color.rgb(250, 218, 221)),
        "Raspberry" to Pair("#E30B5D", Color.rgb(227, 11, 93)),

        // Additional neutral colors
        "Black" to Pair("#000000", Color.rgb(0, 0, 0)),
        "White" to Pair("#FFFFFF", Color.rgb(255, 255, 255)),
        "Silver" to Pair("#C0C0C0", Color.rgb(192, 192, 192)),
        "Gray" to Pair("#808080", Color.rgb(128, 128, 128)),
        "Charcoal" to Pair("#36454F", Color.rgb(54, 69, 79)),
        "Ivory" to Pair("#FFFFF0", Color.rgb(255, 255, 240)),
        "Mint Green" to Pair("#98FF98", Color.rgb(152, 255, 152)),
        "Beige" to Pair("#F5F5DC", Color.rgb(245, 245, 220)),
        "Navy" to Pair("#000080", Color.rgb(0, 0, 128)),
        "Brown" to Pair("#A52A2A", Color.rgb(165, 42, 42))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requestCameraPermission()

        val captureButton: ImageButton = findViewById(R.id.captureButton)
        captureButton.setOnClickListener {
            takePhoto()
        }

        val galleryButton: ImageButton = findViewById(R.id.galleryButton)
        galleryButton.setOnClickListener {
            val intent = Intent(this, Galleryview::class.java)
            startActivity(intent)
        }
        val optionButton: ImageButton = findViewById(R.id.optionButton)
        optionButton.setOnClickListener {
            val intent =
                Intent(this, options::class.java)
            startActivity(intent)
        }
    }

    private fun requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
                if (isGranted) {
                    startCamera()
                } else {
                    Log.e("Camera", "Permission denied")
                }
            }.launch(Manifest.permission.CAMERA)
        } else {
            startCamera()
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder().build()

            val imageAnalysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build().also {
                    it.setAnalyzer(ContextCompat.getMainExecutor(this), ColorAnalyzer())
                }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this as LifecycleOwner,
                    cameraSelector,
                    preview,
                    imageCapture,
                    imageAnalysis
                )
            } catch (exc: Exception) {
                Log.e("Camera", "Use case binding failed", exc)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val picturesDir =
            File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "CyLensScreenshots")
        if (!picturesDir.exists()) picturesDir.mkdirs()

        val photoFile = File(
            picturesDir,
            SimpleDateFormat(
                "yyyyMMdd_HHmmss",
                Locale.US
            ).format(System.currentTimeMillis()) + ".jpg"
        )

        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture.takePicture(outputOptions, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {

                    val bitmap = BitmapFactory.decodeFile(photoFile.absolutePath)
                    val annotatedBitmap = addColorDetailsToBitmap(bitmap)


                    saveAnnotatedBitmap(annotatedBitmap, photoFile)
                    Toast.makeText(
                        this@MainActivity,
                        "Image saved successfully: $photoFile",
                        Toast.LENGTH_LONG
                    ).show()
                }

                override fun onError(exception: ImageCaptureException) {
                    Toast.makeText(this@MainActivity, "Failed to capture image", Toast.LENGTH_SHORT)
                        .show()
                }
            })
    }


    private fun addColorDetailsToBitmap(bitmap: Bitmap): Bitmap {

        val annotatedBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(annotatedBitmap)
        val paint = Paint().apply {
            color = Color.WHITE
            textSize = 150f
            isAntiAlias = true
            setShadowLayer(5f, 0f, 0f, Color.BLACK)
        }


        val colorDetails = binding.colorName.text.toString()


        canvas.drawText(colorDetails, 50f, annotatedBitmap.height - 100f, paint)

        return annotatedBitmap
    }


    private fun saveAnnotatedBitmap(bitmap: Bitmap, file: File) {
        try {
            val fos = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos)
            fos.flush()
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }



    inner class ColorAnalyzer : ImageAnalysis.Analyzer {
        private var lastAnalyzedTimestamp = 0L

        override fun analyze(image: ImageProxy) {
            val currentTimestamp = System.currentTimeMillis()
            if (currentTimestamp - lastAnalyzedTimestamp >= 100) {
                try {
                    val width = image.width
                    val height = image.height

                    //coordinatf
                    val centerX = width / 2
                    val centerY = height / 2

                    val planes = image.planes
                    if (planes.size < 3) {
                        Log.e("Camera", "Image planes not available")
                        return
                    }

                    val yPlane = planes[0]
                    val uPlane = planes[1]
                    val vPlane = planes[2]

                    // Retrieve
                    val yArr = yPlane.buffer
                    val uArr = uPlane.buffer
                    val vArr = vPlane.buffer

                    // pixel
                    val yRowStride = yPlane.rowStride
                    val uRowStride = uPlane.rowStride
                    val vRowStride = vPlane.rowStride

                    val yPixelStride = yPlane.pixelStride
                    val uPixelStride = uPlane.pixelStride
                    val vPixelStride = vPlane.pixelStride

                    // crosshair 3x3
                    var rSum = 0
                    var gSum = 0
                    var bSum = 0
                    var pixelCount = 0

                    for (dy in -1..1) {
                        for (dx in -1..1) {
                            val sampleX = centerX + dx
                            val sampleY = centerY + dy

                            // Y U V
                            val yIndex = (sampleY * yRowStride) + (sampleX * yPixelStride)
                            val uIndex = (sampleY / 2 * uRowStride) + (sampleX / 2 * uPixelStride)
                            val vIndex = (sampleY / 2 * vRowStride) + (sampleX / 2 * vPixelStride)

                            // bound
                            if (yIndex < yArr.remaining() && uIndex < uArr.remaining() && vIndex < vArr.remaining()) {
                                val y = (yArr[yIndex].toInt() and 0xFF)
                                val u = (uArr[uIndex].toInt() and 0xFF) - 128
                                val v = (vArr[vIndex].toInt() and 0xFF) - 128

                                // Convert to RGB
                                val r = (y + (1.370705 * v)).coerceIn(0.0, 255.0).toInt()
                                val g = (y - (0.698001 * v) - (0.337633 * u)).coerceIn(0.0, 255.0).toInt()
                                val b = (y + (1.732446 * u)).coerceIn(0.0, 255.0).toInt()

                                // rgbvalues
                                rSum += r
                                gSum += g
                                bSum += b
                                pixelCount++
                            }
                        }
                    }

                    // calculate pixel
                    if (pixelCount > 0) {
                        val rAvg = rSum / pixelCount
                        val gAvg = gSum / pixelCount
                        val bAvg = bSum / pixelCount

                        Log.d("Camera", "Averaged RGB: ($rAvg, $gAvg, $bAvg)")

                        val closestColor = findClosestColor(rAvg, gAvg, bAvg)

                        runOnUiThread {
                            val (hex, name, rgb) = closestColor
                            binding.colorName.text = "$name\nHex: $hex\nRGB: $rgb"
                        }
                    } else {
                        Log.e("Camera", "No pixels counted for averaging")
                    }

                    lastAnalyzedTimestamp = currentTimestamp
                } catch (e: Exception) {
                    Log.e("Camera", "Error analyzing image: ${e.message}")
                } finally {
                    image.close()
                }
            } else {
                image.close()
            }
        }

        private fun findClosestColor(r: Int, g: Int, b: Int): Triple<String, String, String> {
            var closestColor = ""
            var closestHex = ""
            var minDistance = Double.MAX_VALUE

            for ((colorName, pair) in colorMap) {
                val hexValue = pair.first
                val rgbValue = pair.second
                val colorR = Color.red(rgbValue)
                val colorG = Color.green(rgbValue)
                val colorB = Color.blue(rgbValue)

                // Using Euclidean distance to find the closest color
                val distance = sqrt(
                    (r - colorR).toDouble().pow(2.0) +
                            (g - colorG).toDouble().pow(2.0) +
                            (b - colorB).toDouble().pow(2.0)
                )


                Log.d("ColorDetection", "Checking $colorName: Distance = $distance, RGB = ($r, $g, $b)")

                if (distance < minDistance) {
                    minDistance = distance
                    closestColor = colorName
                    closestHex = hexValue
                }
            }

            Log.d("ColorDetection", "Closest Color: $closestColor, Hex: $closestHex, RGB: ($r, $g, $b)")
            return Triple(closestHex, closestColor, "($r, $g, $b)")
        }
    }


}
